// =================================================================
//                      SIMULADOR DE PLAZOS FIJOS
//                   INTEGRACIÓN CON DOM Y LOCALSTORAGE
// =================================================================

// 1. SELECTORES DEL DOM
// Obtenemos referencias a los elementos HTML con los que vamos a interactuar
const capitalInput = document.getElementById('capital');
const interesAnualInput = document.getElementById('interesAnual');
const plazoDiasInput = document.getElementById('plazoDias');
const calcularBtn = document.getElementById('calcularBtn');
const limpiarResultadosBtn = document.getElementById('limpiarResultadosBtn');
const limpiarHistorialBtn = document.getElementById('limpiarHistorialBtn');

const montoFinalSpan = document.getElementById('montoFinal');
const interesesGanadosSpan = document.getElementById('interesesGanados');
const listaHistorialDiv = document.getElementById('listaHistorial');
const errorMessagesDiv = document.getElementById('errorMessages');

// Constantes para la validación de datos (pueden ser modificadas si es necesario)
const MIN_PLAZO_DIAS = 1; // Para el plazo fijo se suelen usar mínimos como 30 días, pero lo dejo en 1 para flexibilidad
const MAX_PLAZO_DIAS = 365 * 50; // Hasta 50 años en días

// Array para almacenar las simulaciones (se cargará/guardará en localStorage)
let simulacionesGuardadas = [];

// =================================================================
// 2. FUNCIONES DE LÓGICA Y CÁLCULO
// =================================================================

/**
 * Función de cálculo para un plazo fijo simple (interés sobre capital inicial + aportes)
 * Se ajusta a los días
 * @param {number} capital - Capital inicial.
 * @param {number} tasaAnual - Tasa de interés anual (ej: 0.50 para 50%).
 * @param {number} plazoDias - Plazo en días.
 * @returns {object} Objeto con monto final e intereses ganados.
 */
function calcularPlazoFijo(capital, tasaAnual, plazoDias) {
    // Calculamos la tasa diaria
    const tasaDiaria = tasaAnual / 365;
    // Calculamos los intereses ganados para el capital inicial
    const interesesCapital = capital * tasaDiaria * plazoDias;
    // El monto final es el capital inicial más los intereses ganados
    const montoFinal = capital + interesesCapital;
    
    return {
        montoFinal: montoFinal,
        interesesGanados: interesesCapital
    };
}


/**
 * Valida los datos ingresados por el usuario.
 * Muestra mensajes de error directamente en el DOM si hay problemas.
 * @param {number} capital
 * @param {number} interesAnual
 * @param {number} plazoDias
 * @returns {boolean} True si los datos son válidos, false en caso contrario.
 */
function validarDatos(capital, interesAnual, plazoDias) {
    let isValid = true;
    let mensajeError = "";

    if (isNaN(capital) || capital <= 0) {
        mensajeError += "El capital inicial debe ser un número positivo.\n";
        capitalInput.classList.add('error'); // Añade clase para estilo de error
        isValid = false;
    } else {
        capitalInput.classList.remove('error');
    }

    if (isNaN(interesAnual) || interesAnual <= 0) {
        mensajeError += "La tasa de interés anual debe ser un número positivo.\n";
        interesAnualInput.classList.add('error');
        isValid = false;
    } else {
        interesAnualInput.classList.remove('error');
    }

    if (isNaN(plazoDias) || plazoDias < MIN_PLAZO_DIAS || plazoDias > MAX_PLAZO_DIAS) {
        mensajeError += `El plazo debe ser un número de días entre ${MIN_PLAZO_DIAS} y ${MAX_PLAZO_DIAS}.\n`;
        plazoDiasInput.classList.add('error');
        isValid = false;
    } else {
        plazoDiasInput.classList.remove('error');
    }

    // Muestra el mensaje de error general 
     if (!isValid) {
        errorMessagesDiv.innerHTML = mensajeError; // Usamos innerHTML para que <br> funcione
    } else {
        errorMessagesDiv.textContent = ''; // Limpiar mensajes de error si todo es válido
    }
    return isValid;
}

// =================================================================
// 3. FUNCIONES DE MANIPULACIÓN DEL DOM Y EVENTOS
// =================================================================

/**
 * Maneja el evento de clic del botón "Calcular Plazo Fijo".
 */
function manejarCalculo() {
    // Limpiar estilos de error anteriores
    capitalInput.classList.remove('error');
    interesAnualInput.classList.remove('error');
    plazoDiasInput.classList.remove('error');

    const capital = parseFloat(capitalInput.value);
    const interesAnual = parseFloat(interesAnualInput.value);
    const plazoDias = parseInt(plazoDiasInput.value);

    // Validar los datos antes de calcular
    if (!validarDatos(capital, interesAnual, plazoDias)) {
        return; // Detiene la ejecución si los datos no son válidos
    }

    // Calcular el plazo fijo
    const tasaDecimal = interesAnual / 100; // Convertir a decimal
    const resultado = calcularPlazoFijo(capital, tasaDecimal, plazoDias);

    // Mostrar los resultados en la sección de resultados
    montoFinalSpan.textContent = `$${resultado.montoFinal.toFixed(2)}`;
    interesesGanadosSpan.textContent = `$${resultado.interesesGanados.toFixed(2)}`;

    // Guardar la simulación en el historial
    const nuevaSimulacion = {
        id: Date.now(), // Un ID único para cada simulación
        capital: capital,
        interesAnual: interesAnual,
        plazoDias: plazoDias,
        montoFinal: resultado.montoFinal,
        interesesGanados: resultado.interesesGanados,
        fecha: new Date().toLocaleString()
    };
    simulacionesGuardadas.push(nuevaSimulacion);
    guardarSimulaciones(); // Guarda en localStorage
    mostrarHistorial(); // Actualiza la visualización del historial
}

/**
 * Limpia los campos de entrada y los resultados mostrados.
 */
function limpiarResultados() {
    capitalInput.value = '';
    interesAnualInput.value = '';
    plazoDiasInput.value = '';
    montoFinalSpan.textContent = '$0.00';
    interesesGanadosSpan.textContent = '$0.00';
    // También limpia los estilos de error
    capitalInput.classList.remove('error');
    interesAnualInput.classList.remove('error');
    plazoDiasInput.classList.remove('error');
}

/**
 * Muestra las simulaciones guardadas en el div de historial.
 */
function mostrarHistorial() {
    listaHistorialDiv.innerHTML = ''; // Limpiar historial actual

    if (simulacionesGuardadas.length === 0) {
        listaHistorialDiv.innerHTML = '<p>No hay simulaciones guardadas aún.</p>';
        return;
    }

    const ul = document.createElement('ul');
    simulacionesGuardadas.forEach(sim => {
        const li = document.createElement('li');
        li.innerHTML = `
            <strong>Fecha:</strong> ${sim.fecha}<br>
            <strong>Capital:</strong> $${sim.capital.toFixed(2)} |
            <strong>Interés Anual:</strong> ${sim.interesAnual.toFixed(2)}% |
            <strong>Plazo:</strong> ${sim.plazoDias} días<br>
            <strong>Monto Final:</strong> <span class="resaltar">$${sim.montoFinal.toFixed(2)}</span> |
            <strong>Ganancia:</strong> <span class="resaltar">$${sim.interesesGanados.toFixed(2)}</span>
        `;
        ul.appendChild(li);
    });
    listaHistorialDiv.appendChild(ul);
}

/**
 * Limpia todo el historial de simulaciones del DOM y localStorage.
 */
function limpiarHistorial() {
    if (confirm("¿Estás seguro de que quieres eliminar todo el historial de simulaciones?")) {
        simulacionesGuardadas = []; // Vacía el array
        localStorage.removeItem('plazosFijosSimulados'); // Elimina del localStorage
        mostrarHistorial(); // Actualiza la vista
        alert("Historial de simulaciones eliminado.");
    }
}

// =================================================================
// 4. FUNCIONES PARA LOCALSTORAGE
// =================================================================

/**
 * Guarda el array de simulaciones en localStorage.
 */
function guardarSimulaciones() {
    localStorage.setItem('plazosFijosSimulados', JSON.stringify(simulacionesGuardadas));
}

/**
 * Carga el array de simulaciones desde localStorage al inicio.
 */
function cargarSimulaciones() {
    const dataGuardada = localStorage.getItem('plazosFijosSimulados');
    if (dataGuardada) {
        simulacionesGuardadas = JSON.parse(dataGuardada);
    }
    // Asegurarse de que simulacionesGuardadas sea siempre un array
    if (!Array.isArray(simulacionesGuardadas)) {
        simulacionesGuardadas = [];
    }
}

// =================================================================
// 5. INICIO DE LA APLICACIÓN
// =================================================================

// Event Listeners (escuchadores de eventos)
calcularBtn.addEventListener('click', manejarCalculo);
limpiarResultadosBtn.addEventListener('click', limpiarResultados);
limpiarHistorialBtn.addEventListener('click', limpiarHistorial);

// Cuando la página carga, cargamos y mostramos el historial
document.addEventListener('DOMContentLoaded', () => {
    cargarSimulaciones();
    mostrarHistorial();
});
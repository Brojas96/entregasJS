let cuentas = []; // Aquí se cargarán los datos de cuentas.json
let usuarioLogueado = null; // Guardará el objeto del usuario actual

// Referencias a elementos del DOM
const loginSection = document.getElementById('login-section');
const dashboardSection = document.getElementById('dashboard-section');
const loginForm = document.getElementById('login-form');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const welcomeUserSpan = document.getElementById('welcome-user');
const currentBalanceSpan = document.getElementById('current-balance');
const accountNumberSpan = document.getElementById('account-number');
const transactionsTableBody = document.querySelector('#transactions-table tbody');
const depositBtn = document.getElementById('deposit-btn');
const withdrawBtn = document.getElementById('withdraw-btn');
const transferBtn = document.getElementById('transfer-btn');
const logoutBtn = document.getElementById('logout-btn');

// --- Funciones de Carga y Renderizado ---

// Función para cargar los datos de cuentas.json
async function cargarCuentas() {
    try {
        const response = await fetch('./data/cuentas.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        cuentas = await response.json();
    } catch (error) {
        console.error('Error al cargar las cuentas:', error);
        Swal.fire('Error', 'No se pudieron cargar los datos de las cuentas.', 'error');
    }
}

// Función para actualizar el dashboard con los datos del usuario logueado
function actualizarDashboard() {
    if (usuarioLogueado) {
        welcomeUserSpan.textContent = usuarioLogueado.usuario;
        currentBalanceSpan.textContent = `$${usuarioLogueado.cuenta.saldo.toFixed(2)}`;
        accountNumberSpan.textContent = usuarioLogueado.cuenta.numero;
        renderizarTransacciones(usuarioLogueado.cuenta.historial);
    }
}

// Función para renderizar el historial de transacciones
function renderizarTransacciones(historial) {
    transactionsTableBody.innerHTML = ''; // Limpiar tabla antes de añadir
    if (historial && historial.length > 0) {
        // Ordenar el historial por fecha de forma descendente (más recientes primero)
        const historialOrdenado = [...historial].sort((a, b) => new Date(b.fecha) - new Date(a.fecha));

        historialOrdenado.forEach(transaccion => {
            const row = transactionsTableBody.insertRow();
            row.insertCell().textContent = transaccion.fecha;
            row.insertCell().textContent = transaccion.tipo.charAt(0).toUpperCase() + transaccion.tipo.slice(1); // Capitalizar
            row.insertCell().textContent = transaccion.descripcion;
            const montoCell = row.insertCell();
            montoCell.textContent = `$${transaccion.monto.toFixed(2)}`;
            // Opcional: Estilo para montos positivos/negativos
            if (transaccion.tipo === 'deposito' || (transaccion.tipo === 'transferencia' && transaccion.monto > 0)) { // Considerar transferencias recibidas como positivas
                montoCell.classList.add('positive');
            } else {
                montoCell.classList.add('negative');
            }
        });
    } else {
        const row = transactionsTableBody.insertRow();
        const cell = row.insertCell();
        cell.colSpan = 4;
        cell.textContent = 'No hay transacciones registradas.';
        cell.style.textAlign = 'center';
    }
}

// --- Lógica de Autenticación y Navegación ---

// Función para mostrar la sección del dashboard
function showDashboard() {
    loginSection.classList.remove('active');
    loginSection.classList.add('hidden');
    dashboardSection.classList.remove('hidden');
    dashboardSection.classList.add('active');
    actualizarDashboard();
}

// Función para mostrar la sección de login
function showLogin() {
    dashboardSection.classList.remove('active');
    dashboardSection.classList.add('hidden');
    loginSection.classList.remove('hidden');
    loginSection.classList.add('active');
    usuarioLogueado = null; // Limpiar usuario logueado
    loginForm.reset(); // Limpiar formulario de login
    //usernameInput.value = "juanperez"; // Precargar para conveniencia
    //passwordInput.value = "1234"; // Precargar para conveniencia
}

// --- Operaciones Bancarias ---

// Función para registrar una transacción
function registrarTransaccion(tipo, monto, descripcion, cuentaAfectada = usuarioLogueado.cuenta) {
    const fechaActual = new Date().toISOString().split('T')[0]; // Formato YYYY-MM-DD
    cuentaAfectada.historial.push({
        tipo: tipo,
        monto: monto,
        fecha: fechaActual,
        descripcion: descripcion
    });
    // ¡Importante! Esto solo actualiza el array en memoria.
    // Para un proyecto real, necesitarías enviar esto a un servidor/BD.
    // Aquí, para simulación, la memoria es suficiente.
}


// Depósito
depositBtn.addEventListener('click', async () => {
    const { value: montoStr } = await Swal.fire({
        title: 'Depositar Dinero',
        input: 'number',
        inputLabel: 'Ingrese el monto a depositar:',
        inputPlaceholder: 'Ej: 100.00',
        inputAttributes: {
            min: 1,
            step: 0.01
        },
        showCancelButton: true,
        confirmButtonText: 'Confirmar Depósito',
        cancelButtonText: 'Cancelar',
        inputValidator: (value) => {
            if (!value || parseFloat(value) <= 0) {
                return 'Por favor, ingrese un monto válido y positivo.';
            }
        }
    });

    if (montoStr) {
        const monto = parseFloat(montoStr);
        usuarioLogueado.cuenta.saldo += monto;
        registrarTransaccion('deposito', monto, `Depósito en efectivo`);
        actualizarDashboard();
        Swal.fire('¡Éxito!', `Se han depositado $${monto.toFixed(2)}.`, 'success');
    }
});

// Extracción
withdrawBtn.addEventListener('click', async () => {
    const { value: montoStr } = await Swal.fire({
        title: 'Extraer Dinero',
        input: 'number',
        inputLabel: 'Ingrese el monto a extraer:',
        inputPlaceholder: 'Ej: 50.00',
        inputAttributes: {
            min: 1,
            step: 0.01
        },
        showCancelButton: true,
        confirmButtonText: 'Confirmar Extracción',
        cancelButtonText: 'Cancelar',
        inputValidator: (value) => {
            if (!value || parseFloat(value) <= 0) {
                return 'Por favor, ingrese un monto válido y positivo.';
            }
        }
    });

    if (montoStr) {
        const monto = parseFloat(montoStr);
        if (usuarioLogueado.cuenta.saldo >= monto) {
            usuarioLogueado.cuenta.saldo -= monto;
            registrarTransaccion('extraccion', monto, `Extracción de efectivo`);
            actualizarDashboard();
            Swal.fire('¡Éxito!', `Se han extraído $${monto.toFixed(2)}.`, 'success');
        } else {
            Swal.fire('Error', 'Saldo insuficiente para realizar esta extracción.', 'error');
        }
    }
});

// Transferencia
transferBtn.addEventListener('click', async () => {
    const { value: formValues } = await Swal.fire({
        title: 'Realizar Transferencia',
        html:
            '<input id="swal-input1" class="swal2-input" placeholder="Monto a transferir" type="number" step="0.01" min="1">' +
            '<input id="swal-input2" class="swal2-input" placeholder="Número de cuenta destino">',
        focusConfirm: false,
        preConfirm: () => {
            const monto = parseFloat(document.getElementById('swal-input1').value);
            const cuentaDestino = document.getElementById('swal-input2').value.trim();

            if (!monto || monto <= 0) {
                Swal.showValidationMessage('Por favor, ingrese un monto válido y positivo.');
                return false;
            }
            if (!cuentaDestino) {
                Swal.showValidationMessage('Por favor, ingrese un número de cuenta destino.');
                return false;
            }
            if (usuarioLogueado.cuenta.numero === cuentaDestino) {
                Swal.showValidationMessage('No puedes transferir a tu propia cuenta.');
                return false;
            }
            return [monto, cuentaDestino];
        }
    });

    if (formValues) {
        const [monto, cuentaDestinoNumero] = formValues;

        if (usuarioLogueado.cuenta.saldo < monto) {
            Swal.fire('Error', 'Saldo insuficiente para realizar esta transferencia.', 'error');
            return;
        }

        const cuentaDestinoObj = cuentas.find(c => c.cuenta.numero === cuentaDestinoNumero);

        if (cuentaDestinoObj) {
            // Realizar la transferencia
            usuarioLogueado.cuenta.saldo -= monto;
            cuentaDestinoObj.cuenta.saldo += monto;

            // Registrar transacciones en ambos historiales
            registrarTransaccion('transferencia', monto * -1, `Transferencia a ${cuentaDestinoObj.usuario}`, usuarioLogueado.cuenta); // Negativo para el que envía
            registrarTransaccion('deposito', monto, `Transferencia recibida de ${usuarioLogueado.usuario}`, cuentaDestinoObj.cuenta); // Positivo para el que recibe

            actualizarDashboard();
            Swal.fire('¡Éxito!', `Se han transferido $${monto.toFixed(2)} a la cuenta ${cuentaDestinoNumero}.`, 'success');
        } else {
            Swal.fire('Error', 'El número de cuenta destino no existe.', 'error');
        }
    }
});


// --- Event Listeners ---

// Manejo del formulario de login
loginForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Evitar el envío por defecto del formulario

    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    const usuarioEncontrado = cuentas.find(
        (cuenta) => cuenta.usuario === username && cuenta.clave === password
    );

    if (usuarioEncontrado) {
        usuarioLogueado = usuarioEncontrado;
        Swal.fire({
            icon: 'success',
            title: '¡Bienvenido!',
            text: `Sesión iniciada como ${usuarioLogueado.usuario}.`,
            showConfirmButton: false,
            timer: 1500
        });
        showDashboard();
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Error de autenticación',
            text: 'Usuario o contraseña incorrectos. Intenta de nuevo.'
        });
    }
});

// Manejo del botón de cerrar sesión
logoutBtn.addEventListener('click', () => {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "¿Quieres cerrar tu sesión?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, cerrar sesión',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire(
                '¡Sesión cerrada!',
                'Has cerrado tu sesión correctamente.',
                'success'
            );
            showLogin();
        }
    });
});


// --- Inicialización ---
// Cargar las cuentas al cargar el DOM y luego mostrar el login por defecto
document.addEventListener('DOMContentLoaded', () => {
    cargarCuentas();
    showLogin(); // Asegúrate de que la pantalla de login sea la primera que se ve
});